---
name: xclaw-cli-assistant
version: 2.2.1
description: "xclaw-cli 控制面助手：安装/PATH、UMC 登录、runtime 同步、doctor、自更新、skills 列表/读取/安装/更新、schema/catalog 发现、资产上传、会话 Trace。用于安装排障、发现与执行命令。不负责商城/运营/平台/供应链业务（请用 xclaw-mall、xclaw-operate、xclaw-platform、xclaw-supply）。"
metadata:
  category: cli_assistant
  requires:
    bins: ["xclaw-cli"]
  cliHelp: "xclaw-cli --help"
---

# Xclaw CLI Assistant

**本 skill = xclaw-cli 控制面助手**（怎么装、登录、同步命令树、查 schema、排障）。  
**不是**业务域 skill：查订单/客户/平台 OpenAPI/供应链 → 读对应域 skill。

```bash
# BAD — 用本 skill 查商城订单
xclaw-cli skills read xclaw-cli-assistant   # 然后硬猜 mall 路径

# GOOD — 业务先读域 skill
xclaw-cli skills read xclaw-mall references/routing.md
xclaw-cli mall sale-order --help
```

## Skill 地图

| skillId | 展示名 | 负责 | 不负责 |
|---------|--------|------|--------|
| `xclaw-cli-assistant` | Xclaw CLI Assistant | 安装/登录/runtime/doctor/update、skills、schema/catalog、asset、Trace | 具体业务命令路径 |
| `xclaw-mall` | Xclaw Mall | 选品网商城 | CRM / 平台原生 OpenAPI / MRP |
| `xclaw-operate` | Xclaw Operate | 运营 CRM | 商城单 / OpenAPI / 供应链 |
| `xclaw-platform` | Xclaw Platform | 跨境平台卖家 OpenAPI | 商城聚合视图 |
| `xclaw-supply` | Xclaw Supply | MRP / SRM | 商城采购单展示 |

宿主已安装同名 skill 时优先宿主；否则 `xclaw-cli skills read` / `skills install`。

详细手册：

- 内置命令说明 → [`references/plumbing-commands.md`](references/plumbing-commands.md)
- 登录/权限/命令树排障 → [`references/troubleshooting.md`](references/troubleshooting.md)

```bash
xclaw-cli skills read xclaw-cli-assistant references/plumbing-commands.md
xclaw-cli skills read xclaw-cli-assistant references/troubleshooting.md
```

## Agent 标准流程（MUST）

```bash
# 0. 会话 Trace（同一对话多次 CLI 共用；勿跨会话复用）
# PowerShell: $env:XMOON_TRACE_ID = "sess-" + [guid]::NewGuid().ToString("N")
# bash:       export XMOON_TRACE_ID="sess-$(uuidgen | tr -d '-' | tr '[:upper:]' '[:lower:]')"

# 1. 环境与登录（首次或报错时）
xclaw-cli doctor --json
xclaw-cli auth status --json
xclaw-cli auth login --env prod --json          # no_token / expired 时

# 2. 命令树 / 二进制异常
xclaw-cli update --json                         # 有 update 子命令时
xclaw-cli runtime sync --global --json

# 3. 找场景与命令
xclaw-cli skills list --json
xclaw-cli skills read xclaw-cli-assistant       # 控制面
xclaw-cli skills read xclaw-operate             # 按域：mall / operate / platform / supply

# 4. 确认路径 → 查参数 → 执行
xclaw-cli operate --help
xclaw-cli schema operate customer customer alibaba search --json
xclaw-cli operate customer customer alibaba search --json ...   # 查询加 --json
xclaw-cli operate order price-change --dry-run --json ...       # 变更先 --dry-run
```

仍不确定路径：读域 skill 的 `references/routing.md`，再对分组逐层 `--help` / `-h`。

## 四条业务线（顶层 pack）

| 命令 | 覆盖（以 live `--help` 为准） |
|------|------------------------------|
| `xclaw-cli mall` | 选品网：销售/采购单、平台订单视图、商品、售后、发票、1688 BI |
| `xclaw-cli operate` | CRM：客户、询盘线索、跟进、改价、定制报价、工单 |
| `xclaw-cli platform` | 跨境平台 OpenAPI：Shopee、Temu、TikTok、速卖通等 |
| `xclaw-cli supply` | 供应链：`mrp` + `srm` |

## 内置命令速查

| 命令 | 何时用 |
|------|--------|
| `version` | CLI / release / pack 版本 |
| `auth login\|status\|refresh\|logout\|source` | 登录、续期、诊断凭证 |
| `runtime sync --global` | **同步命令树**（首选） |
| `runtime check` / `bootstrap` | 诊断或首次拉 release |
| `manifest sync` | legacy（仅 `XMOON_COMMAND_SOURCE=manifest`） |
| `skills list\|read\|install\|update` | 目录、内置文档、多宿主安装/更新 |
| `schema <pack> <path...>` | 必填参数与嵌套 body |
| `catalog search` | 可选；自然语言搜 commandKey |
| `asset` | 上传/列出图片与媒体 |
| `doctor` | 一键体检 + `nextActions` |
| `update` | 自更新二进制；找不到命令时先 update 再 sync |

子命令、flag、JSON、`@file` → [`plumbing-commands.md`](references/plumbing-commands.md)

## 场景卡

### A. 首次使用

```bash
xclaw-cli doctor --json
xclaw-cli auth login --env prod --json
xclaw-cli runtime sync --global --json
xclaw-cli skills install xclaw-cli-assistant --scope user --agent universal
xclaw-cli version --json
```

### B. 找命令（用户说意图、不知路径）

1. `skills list` → `skills read <域 skill>` / `references/routing.md`
2. `<pack> <group> --help` 逐层确认
3. `schema <pack> ... --json` 后执行
4. 可选：`catalog search --query "<意图>" --json`（低置信时跟 `suggestedSkills`）

### C. 写操作（改价、催货、审核等）

1. 向用户确认单号/范围
2. `--dry-run --json`（若支持）
3. 确认后再去掉 `--dry-run` 执行
4. **不要**把 token 明文输出给用户

### D. 登录 / 401 / 403

| 症状 | 第一步 |
|------|--------|
| 未登录 / token 过期 | `auth login --env prod` |
| 401 / `AUTH_TOKEN_EXPIRED` | `auth refresh` → 失败则 `login` |
| 403 / 业务无权限 | 账号权限问题，非 CLI 配置 |

完整决策树 → [`troubleshooting.md`](references/troubleshooting.md)

### E. 命令不存在 / 业务异常

```bash
xclaw-cli update --help    # 失败 → CLI 过旧，提醒用户升级二进制
xclaw-cli update --json
xclaw-cli runtime sync --global --json
# 重试原命令
```

### F. 参数非法 / PowerShell JSON

- `error.code=USAGE_INVALID` → `schema ... --json`
- object/array flag（如 `--condition`）用 **`@文件路径`**，尤其 Windows

### G. 会话 Trace

- env：`XMOON_TRACE_ID`（别名 `XCLAW_TRACE_ID` 优先）
- 新会话生成一次；同会话内每次 CLI 保留同一值
- `--json` 的 `meta.traceId` / `meta.invocationId` 均为该值
- 出站：`Xclaw-Session-Id` 与 `X-Request-Id` 同为该值（不再注入 `X-Trace-Id`）

```powershell
$env:XMOON_TRACE_ID = "sess-" + [guid]::NewGuid().ToString("N")
xclaw-cli --debug --env test version --json
```

## 转交哪个域 skill

| 用户在聊 | skill |
|----------|-------|
| 商城销售/采购单、物流、商品、售后、发票、1688 参谋 | `xclaw-mall` |
| 客户档案、询盘、跟进、改价、报价、ITSM 工单 | `xclaw-operate` |
| 在 Shopee/Temu 等**平台卖家 API** 上操作 | `xclaw-platform` |
| MRP 计划/分仓库存/催货、SRM 采购单与供应商 | `xclaw-supply` |

```bash
xclaw-cli skills read xclaw-mall
xclaw-cli skills read xclaw-mall references/scenarios.md
```

内容与当前 CLI 二进制版本绑定；更新 CLI 后重新 `skills read`。
