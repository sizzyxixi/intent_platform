# 内置命令手册（非业务）

与 `xclaw-cli --help` 同步。业务命令（mall / operate / platform / supply）见各域 skill。

## 全局约定

### 全局 flag

| Flag | 说明 |
|------|------|
| `--json` | 机器可读 JSON；Agent **默认加** |
| `--dry-run` | 变更类命令只打印等价 curl，不发 HTTP |
| `--env dev\|test\|uat\|prod` | 运行环境（默认 `prod`；也可用 `XMOON_AUTH_ENV`） |
| `--output json\|text\|raw` | 输出格式 |
| `--debug` | 调试日志 |

### JSON 响应结构

成功：

```json
{ "ok": true, "data": { ... }, "meta": { "command": "...", "coreVersion": "..." } }
```

失败：

```json
{ "ok": false, "error": { "code": "...", "message": "...", "messageZh": "..." }, "meta": { ... } }
```

Agent 读 `ok`；失败时看 `error.code` 与 `error.messageZh`（排障见 [`troubleshooting.md`](troubleshooting.md)）。

### 结构化参数 `@file`

object / array 类 flag（如 `--condition`）支持从文件读 JSON，避免 shell 转义问题：

```bash
xclaw-cli operate customer customer alibaba search \
  --page 1 --size 20 --json \
  --condition @condition.json
```

Windows / PowerShell 传内联 JSON 极易失败，**优先 `@file`**。

---

## version

查看 CLI 与 runtime 版本。

```bash
xclaw-cli version --json
```

常见字段：`version`、`core`、`commit`、`buildDate`、`env`、`releaseVersion`、`releaseId`、`pack-code`（已 sync 时）。

---

## auth

UMC OAuth 登录与本地 token 管理。**业务 HTTP 请求依赖有效凭证。**

| 子命令 | 用途 |
|--------|------|
| `login` | 浏览器授权，写入本地凭证 |
| `status` | 登录态（env / 共享文件 / 本地优先链，**不发远程请求**） |
| `refresh` | 用 refresh_token 续期 |
| `logout` | 清本地凭证，尝试远程 revoke |
| `source` | 诊断凭证来源与 manifest 是否存在 |

### login

```bash
xclaw-cli auth login --env prod --json
```

- 自动打开浏览器；失败时 stderr 会打印授权 URL，可手动打开
- `--login-timeout` 默认 180s
- 可选 `--api-base-url` / `--login-base-url` 覆盖端点

### status

```bash
xclaw-cli auth status --json
```

不发远程请求；与业务命令同一优先链：`XCLAW_UMC_TOKEN` → `.xclaw.env.json` → 本地 `credentials.json`。

`data` 关键字段：`status`、`code`、`source`、`message` / `messageZh`、可选 `expiresAt` / `fallbackReason`。

`data.status`：

| 值 | 含义 |
|----|------|
| `logged_in` | 当前生效凭证有效 |
| `expired` | 当前可判定凭证已过期且无可用回退 |
| `no_token` | 无可用凭证 |

`data.code`（凭证层）：

| code | 含义 |
|------|------|
| `AUTH_OK` | 当前生效凭证有效 |
| `AUTH_ENV_MISSING` | 未注入 `XCLAW_UMC_TOKEN`，且无其它可用凭证 |
| `AUTH_ENV_INVALID` | env token 无效，且无可用回退 |
| `AUTH_ENV_EXPIRED` | env token 过期，且无可用回退 |
| `AUTH_XCLAW_FILE_INVALID` | 共享文件 token 无效，且无可用回退 |
| `AUTH_XCLAW_FILE_EXPIRED` | 共享文件 token 过期，且无可用回退 |
| `AUTH_LOCAL_MISSING` | 本地无可用 token |
| `AUTH_LOCAL_EXPIRED` | 本地 token 已过期 |
| `AUTH_NO_CREDENTIAL` | 三路皆无 |

高优先级失败但已回退成功时：`code=AUTH_OK`，`source` 为实际来源，并带 `fallbackReason` / `warnings`。

业务 HTTP 401 不在本命令内探测，表现为业务命令 `error.code=AUTH_TOKEN_EXPIRED`。

### refresh

```bash
xclaw-cli auth refresh --json
```

有 refresh_token 时续期；缺失则报错，需重新 `login`。

### source

```bash
xclaw-cli auth source --json
```

与 `status` 共用同一套 `code` / `status` / `source` / `messageZh`；额外提供 `runtimeAuth`（`envVarPresent`、`localFilePresent`、`manifestExists` 等）。凭证冲突或「明明登录了仍 401」时必查。

### 环境

`dev` / `test` / `uat` / `prod`；通过 `--env` 或环境变量 `XMOON_AUTH_ENV` 指定。

---

## runtime

从 API Manager 拉取命令树 release 与 manifest 缓存。**业务子命令依赖 sync 后的本地 cache。**

| 子命令 | 用途 |
|--------|------|
| `sync --global` | **日常首选**：同步全局 manifest / 命令树 |
| `sync <pack>` | 同步单个 pack |
| `sync --all` | 同步全部 pack |
| `check` | 检查 release 与 pack 缓存 |
| `bootstrap [pack]` | 拉 release；可选顺带拉单 pack manifest |

```bash
# 命令树过期、bootstrap/manifest 报错、新装 CLI 后
xclaw-cli runtime sync --global --json

# 诊断 runtime 是否可用
xclaw-cli runtime check --json
```

`sync` 可选 `--force` 强制刷新 cache。

### 与 manifest sync 的区别

- **`runtime sync`**：当前默认路径（Runtime 模式）
- **`manifest sync`**：legacy manifest 模式（`XMOON_COMMAND_SOURCE=manifest` 时）；一般用户用 runtime 即可

```bash
xclaw-cli manifest sync --json          # legacy
xclaw-cli manifest sync --force --json  # 强制
```

---

## skills

面向 Agent：远程目录 + 内置文档 + 多宿主安装。

| 子命令 | 用途 |
|--------|------|
| `list [--local-only] [--category]` | 默认拉后台/OSS catalog；`--local-only` 仅内置 |
| `read <skill> [path]` | 读内置 `SKILL.md` / references |
| `install <id\|all> --scope user\|project --agent ...` | 下载 zip 到宿主 skill 目录，写 `~/.xmoon/skills/state.json` |
| `update [id\|all]` | 按 state 多路径覆盖更新 |

```bash
xclaw-cli skills list --json
xclaw-cli skills install xclaw-cli-assistant --scope user --agent universal
xclaw-cli skills install all --agent all
xclaw-cli skills update all
xclaw-cli skills read xclaw-cli-assistant
xclaw-cli skills read xclaw-operate references/routing.md
xclaw-cli skills list xclaw-mall/references
```

Skill 分层：

| skillId | 展示名 | 类别 |
|---------|--------|------|
| `xclaw-cli-assistant` | Xclaw CLI Assistant | cli_assistant（控制面） |
| `xclaw-mall` | Xclaw Mall | solution |
| `xclaw-operate` | Xclaw Operate | solution |
| `xclaw-platform` | Xclaw Platform | solution |
| `xclaw-supply` | Xclaw Supply | solution |

旧 id `xclaw-shared` / `cli-shared` 仍可解析到本助手（兼容）。

---

## schema

查业务命令参数结构（必填项、类型、分页、嵌套 body）。

```bash
# 导航：只看分组
xclaw-cli schema operate --json

# leaf：看完整 args
xclaw-cli schema operate customer customer alibaba search --json
```

- 中间节点返回 `children`
- leaf 返回 `args`、`method`、`path`
- 与 `--help` 互补；**嵌套 JSON 参数以 schema 为准**

---

## catalog（可选，非主路径）

按自然语言搜命令键；**skills 优先**，catalog 作补充。

| 子命令 | 用途 |
|--------|------|
| `search --query "<意图>"` | 模糊匹配 commandKey |
| `explain <commandKey>` | 解释某命令 |
| `schema <commandKey>` | 按 catalog 键查 schema |
| `index` | 列出 catalog 索引 |

```bash
xclaw-cli catalog search --query "查客户" --json
```

低置信或未命中时 JSON 可能含 `suggestedSkills`、`nextStep`、`skillHintReason`，按提示 `skills read` 对应域 skill。

---

## asset

上传与管理图片、媒体素材。需先 `auth login`。每人每日上传数量有限制（默认每天最多 500 个，图片与媒体合计）。

| 子命令 | 限制 | 用途 |
|--------|------|------|
| `upload-images` | 单文件 ≤2MB，批量合计 ≤18MB，可 `--file` 重复 | 批量上传图片（jpg/jpeg/png/gif/webp/bmp） |
| `list-image` | — | 分页列出当前用户图片 |
| `upload-media` | 单文件 ≤20MB，**不支持批量** | 上传单个媒体文件 |
| `list-media` | — | 分页列出当前用户媒体 |

```bash
xclaw-cli asset upload-images --file ./a.jpg --file ./b.png --json
xclaw-cli asset list-image --page-size 20 --marker "<nextMarker>" --json
xclaw-cli asset upload-media --file @./clip.mp4 --json
xclaw-cli asset list-media --date 2026-06-21 --json
```

- 上传成功响应含公开访问 URL
- 图片默认保留 1 天，上传/列表 JSON 中含 `lifecycle` 说明
- `--dry-run` 只返回将上传的信息，并校验大小与配额，不实际上传

---

## doctor

一键环境体检，输出可执行的 `nextActions`。

```bash
xclaw-cli doctor --json
```

检查项：`coreVersion`、`env`、`config`、`auth`、`runtime`、`launcher`。

- `status`: `ok` / `warning` / `failed`
- 优先跟 `data.nextActions` 逐步修复

---

## update

CLI 自更新。metadata 默认地址见 `config/build.defaults.yaml` 的 `cliMetadataUrl`；也可通过 `--metadata-url` 或 `XCLAW_METADATA_URL` / `XMOON_METADATA_URL` 覆盖。

日常执行其他命令时，CLI 会按 TTL（默认 24h，`XCLAW_UPDATE_TTL_SECONDS` 可覆盖）检查 OSS metadata；若有新版本，在 **stderr** 提示执行 `xclaw-cli update`。设置 `XCLAW_DISABLE_UPDATE_NOTICE=1` 可关闭该提示（不自动下载替换）。

### 何时用

- CLI 版本落后，文档/schema 里有子命令但本地 `--help` 没有
- **找不到相关命令**（unknown command、bootstrap 失败）
- **业务命令异常报错**，且 `auth` / 登录态正常、`runtime sync` 后仍失败

### 标准排障顺序

```bash
xclaw-cli update --json
xclaw-cli runtime sync --global --json
# 重试原业务命令
```

可先 `update --dry-run --json` 查看是否有新版本。

### 无 update 子命令（CLI 过旧）

```bash
xclaw-cli update --help   # 失败 → 当前二进制过旧
```

不要反复 `runtime sync`；提醒用户从官方渠道升级到**最新版 xclaw-cli 二进制**。

升级后再 `runtime sync --global` 并重试。

### 执行示例

```bash
xclaw-cli update --metadata-url "<url>" --json
# 或设置 XCLAW_METADATA_URL / XMOON_METADATA_URL 后直接：
xclaw-cli update --json
xclaw-cli update --dry-run --json
```

可选：`--install-dir`、`--platform`、`--force`、`--skip-aliases`。
