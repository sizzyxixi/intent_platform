# 排障：登录、权限、命令树、参数

业务命令失败时按本页处理；公共命令细节见 [`plumbing-commands.md`](plumbing-commands.md)。

## 快速决策

```
业务命令失败
  → doctor --json                    # 看 nextActions
  → auth status --json               # no_token / expired → login
  → auth source --json               # 凭证从哪来、是否 active
  → auth refresh 或 auth login       # 401 / expired
  → update --json                    # 找不到命令 / 命令报错（有 update 时）
  → runtime sync --global --json     # 命令树 / manifest 问题
  → schema <pack> <cmd> --json       # USAGE_INVALID
  → 重试业务命令
```

## 权限「不知道有没有」标准步骤

1. `xclaw-cli doctor --json` — 跟 `data.nextActions`
2. `xclaw-cli auth status --json` + `xclaw-cli auth source --json`
3. `status` 为 `no_token` 或 `expired` → `xclaw-cli auth login --env prod --json`
4. `status` 为 `logged_in` 但业务仍报 401 → `xclaw-cli auth refresh --json`；失败则重新 `login`
5. HTTP 403 或业务响应 `code != 0` 且提示无权限 → **账号/角色/数据范围不足**，换有权限的账号或让用户找管理员；**不是**反复 login 能解决的
6. `doctor` 或报错提示 runtime → `xclaw-cli runtime sync --global --json`，仍失败则 `runtime check --json`
7. **找不到命令 / 业务命令报错**（auth 正常）→ `xclaw-cli update --json`（无 `update` 子命令则提醒用户升级最新 CLI 二进制）→ `runtime sync --global` → 重试
8. `error.code` 为 `USAGE_INVALID` → `schema` 查参数；JSON 参数用 `@file`
9. 仍失败：确认 `--env` 与目标环境一致（prod/uat 等）

## 错误码对照

| `error.code` / HTTP | 含义 | 处理 |
|---------------------|------|------|
| `AUTH_TOKEN_EXPIRED` / HTTP **401** | token 过期或无效 | `auth refresh` → 失败则 `auth login` |
| `AUTH_PERMISSION_DENIED` | OAuth 登录被拒绝 / state 校验失败 | 换账号重新 `auth login` |
| HTTP **403** / 业务 body 权限提示 | 接口级无权限（已认证但无权访问该资源） | 确认账号角色与数据范围；告知用户权限不足 |
| `no_token` / `CONFIG_NOT_FOUND` | 未登录 | `auth login` |
| `USAGE_INVALID` | 缺参、JSON 解析失败、flag 非法 | `schema <pack> <path> --json`；`--condition @file` |
| runtime / manifest / bootstrap 相关 | 命令树过期或未 sync | `runtime sync --global`；`runtime check` |
| `NETWORK_REQUEST_FAILED` | 网络失败或非 401/2xx | 看 `error.details.status`、`body`；查网络与环境 URL |

注意：HTTP **401** 映射为 `AUTH_TOKEN_EXPIRED`；HTTP **403** 一般为 `NETWORK_REQUEST_FAILED`，**不要**当成 token 过期去 refresh。

## 凭证来源（auth source）

自动模式（`auth source`）优先级大致为：

1. 环境变量 token（如 XClaw 注入）
2. XClaw 共享 env 文件
3. `~/.xmoon` 本地凭证（`auth login` 写入）

- 在 Cursor / XClaw 宿主内 Agent 可能自动带上共享 token
- 独立终端通常需先 `auth login`
- **`auth status` / `auth source`** 与业务命令同一优先链：`XCLAW_UMC_TOKEN` → `.xclaw.env.json` → 本地 `credentials.json`
- 看 `data.code`：`AUTH_OK` / `AUTH_ENV_MISSING` / `AUTH_ENV_EXPIRED` / `AUTH_LOCAL_EXPIRED` 等（详见 plumbing-commands）
- 业务请求 HTTP 401 → `error.code=AUTH_TOKEN_EXPIRED`（token 本地看似可用但远端拒绝）
- **禁止**向用户输出 access_token 明文

## 常见场景

### 「未找到本地凭证，请先 auth login」

```bash
xclaw-cli auth login --env prod --json
xclaw-cli runtime sync --global --json
```

### 浏览器打不开 / 无交互环境

`login` 失败时 stderr 有授权 URL，复制到可交互环境完成 OAuth，或在该环境执行 `auth login`。

### 命令不存在 / unknown command / bootstrap 失败

```bash
# 1. 是否有 update 子命令？
xclaw-cli update --help
# 无 → 提醒用户从官方渠道升级到最新 xclaw-cli 二进制

# 2. 有 update 时
xclaw-cli update --json
xclaw-cli runtime sync --global --json
xclaw-cli runtime check --json
xclaw-cli version --json    # 确认 CLI 版本与 pack-code
# 重试原业务命令
```

不要凭记忆拼业务路径；用 `skills read xclaw-cli-assistant` / 域 skill + 逐层 `--help` + `schema`。

### 业务命令报错但 auth / runtime 正常

登录态正常、`runtime sync` 后仍报错或行为异常：

```bash
xclaw-cli update --json
xclaw-cli runtime sync --global --json
# 重试原命令
```

仍失败：查 `schema` 确认参数；403 / 业务 `code!=0` 按权限不足处理，不是继续 update。

### parse flag condition / invalid json

PowerShell 内联 JSON 常失败：

```bash
# 写入 condition.json 后
xclaw-cli operate ... --condition @condition.json --json
```

### doctor launcher warning

`doctor --json` 的 `launcher` 检查异常时，跟 `data.nextActions` 处理；必要时请用户从官方渠道重装/升级 CLI 二进制。

### Trace ID 未关联 / 并发会话混淆

1. Agent 会话开始时设置 **`XMOON_TRACE_ID`**（或 `XCLAW_TRACE_ID`），同一会话内所有 `xclaw-cli` 复用。
2. 核对：`xclaw-cli --debug ... --json`，stderr 应有 `trace context`（`source=env`、`traceId`、`invocationId`、`pid`）；二者应等于 env。
3. 出站头 **`Xclaw-Session-Id`** 与 **`X-Request-Id`** 均为该 env 值；另开终端用不同 `XMOON_TRACE_ID` 时应能区分。
4. 未设 env 时两者均为同一 `inv-...`（单进程随机），多次 CLI **不会**天然相同——这是预期。

## 仍无法解决

收集（**不含 token**）：

- `xclaw-cli doctor --json`
- `xclaw-cli auth status --json` 与 `auth source --json`（可打码）
- 失败命令与 `error.code` / `messageZh`
- `xclaw-cli version --json`

交给用户或运维排查账号权限与环境配置。
