# platform：怎么找命令

## 推荐顺序（禁止硬猜）

```bash
# 1) 锁平台
xclaw-cli platform --help

# 2) 平台内搜能力（看帮助文案关键词）
xclaw-cli platform shopee --help
xclaw-cli platform temu --help
xclaw-cli platform tiktok-full --help

# 3) 下钻到 leaf + schema
xclaw-cli platform shopee order-list --help
xclaw-cli schema platform shopee order-list get --json

# 4) 执行（查询）
xclaw-cli platform shopee order-list get --json ...
```

## catalog（可选，结果需过滤）

```bash
xclaw-cli catalog search --query "shopee order" --json
xclaw-cli catalog search --query "temu goods stock" --json
xclaw-cli catalog search --query "tiktok-full abnormal" --json
```

注意：

- `matches` 里常混有 `mall ...` 路径 → **丢弃**，只保留以 `platform ` 开头的 `generatedCommandPath`
- 中文关键词有时命中商城 BI（如「异常」→ 1688 参谋）→ 改用英文 OpenAPI 词或先锁平台再 `--help`
- 拿到路径后仍要 `schema platform <各段> --json`，不要直接臆造 flags

## 已验证的 live 片段（会随版本变）

| 意图 | 下钻起点 |
|------|----------|
| Shopee 搜订单 | `platform shopee order-list get` |
| TikTok 全托异常单 | `platform tiktok-full abnormal-orders` |
| Temu 活动 / 库存相关 | `platform temu --help` 后按 `activity-*` / `goods-stock-*` 下钻 |

写操作：`--dry-run` + 用户确认 shop / 单号后再执行。
