# platform 平台入口索引

与 live `xclaw-cli platform --help` 对齐（当前约 25 个一级入口、5800+ 命令）。  
**选定平台后**继续 `platform <入口> --help` 或 `schema`；不要背深层路径。

| 入口 | 用户常说法 |
|------|------------|
| `alibaba` | 1688、阿里巴巴国内站 |
| `alibaba-icbu` | 阿里国际站、ICBU |
| `aliexpress` | 速卖通、AE |
| `coupang` | Coupang、酷澎 |
| `ebay` | eBay |
| `emag` | eMAG |
| `etsy` | Etsy |
| `joom` | Joom |
| `jumia` | Jumia |
| `lazada` | Lazada、来赞达 |
| `mercadolibre` | 美客多、Mercado Libre、ML |
| `newegg` | Newegg、新蛋 |
| `ozon` | Ozon |
| `pdd` | 拼多多、PDD |
| `qooten` | Qooten |
| `shein` | 希音、SHEIN |
| `shopee` | Shopee、虾皮 |
| `shopify` | Shopify |
| `temu` | Temu 跨境 / 半托全托视具体子命令 |
| `temu-local` | Temu 本土 |
| `tiktok` | TikTok 半托 |
| `tiktok-full` | TikTok 全托、Global Selling、异常单 |
| `wildberries` | WB、Wildberries |
| `wish` | Wish |
| `yandex` | Yandex Market |

刷新列表：

```bash
xclaw-cli platform --help
xclaw-cli schema platform --json
```

## 和 mall 的边界

| 场景 | 用 |
|------|-----|
| 选品网 / MCP / 商城侧平台订单、1688 授权店铺、商城物流轨迹 | `mall platform-order`（`xclaw-mall`） |
| 平台卖家 OpenAPI（shop-id、官方订单/商品/物流接口） | `platform <平台名>`（本 skill） |
| 1688 **官方** OpenAPI | `platform alibaba`（不是 mall BI） |

## 深树策略

平台下常有上百个平铺/分组命令（如 `shopee` 的 `order-list`、`add-item`；`tiktok-full` 的 `abnormal-orders`）。  

1. `platform <平台> --help` 用关键字在输出里搜（order / goods / stock / refund）  
2. 命中分组后再 `--help` / `schema`  
3. `catalog search` 仅作提示，且 **只信** `generatedCommandPath` 以 `platform ` 开头的结果  
