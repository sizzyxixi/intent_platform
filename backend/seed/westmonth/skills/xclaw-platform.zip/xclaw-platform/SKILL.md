---
name: xclaw-platform
version: 2.2.1
description: "跨境平台卖家 OpenAPI（platform）：按平台入口转发 Shopee/Temu/TikTok/速卖通/1688 等官方能力。调用平台卖家接口（店铺/订单等）时使用；命令树很深，先锁定平台再分层 --help 与 schema，勿硬编码路径。不负责选品网商城聚合视图（xclaw-mall）或 CLI 安装登录（xclaw-cli-assistant）。"
metadata:
  category: solution
  packCode: platform
  requires:
    bins: ["xclaw-cli"]
  cliHelp: "xclaw-cli platform --help"
---

# Xclaw Platform

**开始前 MUST：** `doctor` / `auth status`；再读本路由。参数以 live `--help` / `schema` 为准。  
公共能力 → `xclaw-cli skills read xclaw-cli-assistant`

登录失败、权限不明、命令树过期 → `xclaw-cli skills read xclaw-cli-assistant references/troubleshooting.md`

## 这条业务线是干什么的

`xclaw-cli platform` = **各跨境电商平台官方 OpenAPI 转发**（当前约 **5800+** 条子命令，第一层按平台名）。  
用户说「在 Shopee / Temu / TikTok 店铺后台调接口」→ 这里。  
用户说「选品网里的平台订单 / 1688 授权店铺 / 商城物流」→ **`xclaw-mall` 的 `platform-order`**，不是本 skill。

```bash
# BAD — 商城侧视图当成平台 OpenAPI
xclaw-cli mall platform-order auth-shop-list ...

# BAD — 硬猜深层路径
xclaw-cli platform shopee somehow-get-orders ...

# GOOD — 先锁平台，再下钻
xclaw-cli platform --help
xclaw-cli platform shopee --help
xclaw-cli platform shopee order-list --help
xclaw-cli schema platform shopee order-list get --json
```

## Agent 标准流程（MUST）

1. **锁定平台入口**：`xclaw-cli platform --help`（或本 skill [`scenarios.md`](references/scenarios.md)）
2. **下钻分组**：`xclaw-cli platform <平台> --help` → 继续对子命令 `--help`，直到 leaf
3. **查参数**：`xclaw-cli schema platform <平台> <path...> --json`
4. **执行**：查询加 `--json`；写操作先 `--dry-run`，并向用户确认 shop / 单号
5. **可选补充**：`catalog search`（结果常混入 mall；**只采用 `platform <平台>` 开头的路径**）

```bash
xclaw-cli platform shopee order-list get --json ...
xclaw-cli platform tiktok-full abnormal-orders --help
xclaw-cli catalog search --query "shopee order" --json   # 过滤 path 以 platform 开头
```

## 一级平台入口（live：`platform --help`）

| 入口 | 用户常说法 / 覆盖摘要 |
|------|------------------------|
| `alibaba` | 1688：账号、商品、类目、订单、物流、库存、退款、发票、素材 |
| `alibaba-icbu` | 阿里国际站 ICBU：商品报价、分销、物流、营销、RFQ 等 |
| `aliexpress` | 速卖通 AE：授权、商品、订单、物流、评价、营销 |
| `coupang` | Coupang：物流、品类、商品、订单、CGF、客服、退换货、结算 |
| `ebay` | eBay：账号、商品库存、订单履约、营销、合规等 |
| `emag` | eMAG：商品报价、订单、AWB、退货、发票 |
| `etsy` | Etsy：刊登、库存、订单、收据、退货、店铺 |
| `joom` | Joom：品类、商品、订单、发货、自提 |
| `jumia` | Jumia：授权、类目、商品、订单、账单、店铺 |
| `lazada` | Lazada：授权、类目、商品、活动、订单、物流 |
| `mercadolibre` | Mercado Libre：品类、商品、订单、FBJ、自提 |
| `newegg` | Newegg：Feed、商品库存、订单、RMA、发货 |
| `ozon` | Ozon：品类、商品、订单、FBO/FBS、促销、财务、评价 |
| `pdd` | 拼多多：订单、售后、地址、发票、消息、推广 |
| `qooten` | Qooten：品类、商品、库存、订单、履约、退货、客服 |
| `shein` | SHEIN：公告、属性、店铺、订单、仓库、发货 |
| `shopee` | Shopee / 虾皮：授权、店铺、商品批量、营销、订单、物流 |
| `shopify` | Shopify：商品、客户、订单、库存、履约、退款、折扣 |
| `temu` | Temu 跨境：授权、包装、活动报名、订单等 |
| `temu-local` | Temu 本土：售后、取消、退款、逆向物流 |
| `tiktok` | TikTok **半托**：店铺、商品、订单、包裹、库存、价格、售后、达人 |
| `tiktok-full` | TikTok **全托** / Global Selling：商品、类目、异常单等 |
| `wildberries` | WB：费率、报告、余额、供应与验收 |
| `wish` | Wish：OAuth、类目、商品、订单、物流、发票、工单 |
| `yandex` | Yandex：刊登、商品、订单、物流、价格、报表 |

入口会随 release 增减：**以 `xclaw-cli platform --help` 为准**，上表为索引而非硬编码全集。

## 真实下钻示例（勿当唯一路径）

```bash
# Shopee 搜订单（leaf）
xclaw-cli platform shopee order-list --help
xclaw-cli schema platform shopee order-list get --json
xclaw-cli platform shopee order-list get --json ...

# TikTok 全托异常单
xclaw-cli platform tiktok-full --help
xclaw-cli platform tiktok-full abnormal-orders --help
xclaw-cli schema platform tiktok-full abnormal-orders --json
```

更多搜法 → [`references/routing.md`](references/routing.md)  
平台别名表 → [`references/scenarios.md`](references/scenarios.md)

## 注意事项

- **必须先定平台**；同一「查订单」在不同平台命令完全不同
- 子命令极多、命名偏英文 OpenAPI；**禁止背路径 / 禁止 invent 命令名**
- `catalog search` 可能返回 `mall ...`：忽略非 `platform` 路径，或改走本 skill 分层 `--help`
- `xclaw-cli runtime` 是 CLI 自身命令，不是 platform 业务
- 平台限流 / 业务错误看 `--json` 的 `error`；勿无间隔重试
- 写操作：确认 **shop-id / 订单号 / 站点** 后再执行

## 不在本 skill

| 场景 | 去哪 |
|------|------|
| 选品网平台订单视图、MCP/1688 授权店铺、商城物流 | `xclaw-mall`（`platform-order` 等） |
| CRM 客户 / 询盘 / 改价 | `xclaw-operate` |
| 安装 / 登录 / sync / schema 排障 | `xclaw-cli-assistant` |
