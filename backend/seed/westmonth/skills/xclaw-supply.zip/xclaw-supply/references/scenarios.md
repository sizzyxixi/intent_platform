# supply 子命令索引

## mrp

见 `xclaw-cli supply mrp --help`。核心能力：

- 查：`goods`、`goods-plans`、`goods-warehouse-inventories`、`purchase-order-details` …
- 写：`goods-requirement`（催货，需用户确认）

## srm

见 `xclaw-cli supply srm --help`：

- `supplier`、`purchase-order`、`processing-order`、`administrative-order`
- `shipment-detail`、`sku-procurement-detail`

## 采购单 disambiguation

| 用户说的「采购单」 | 更可能 |
|--------------------|--------|
| 商城/选品网订单列表 | `mall sale-order purchase-show-formal-order-list` |
| SRM 系统采购单 | `supply srm purchase-order` |
| SKU 在途采购明细 | `supply mrp purchase-order-details` |
