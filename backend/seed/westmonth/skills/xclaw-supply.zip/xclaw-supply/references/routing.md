# supply：catalog 示例

```bash
xclaw-cli catalog search --query "分仓库存" --json
xclaw-cli catalog search --query "催货" --json
xclaw-cli catalog search --query "供应商" --json
xclaw-cli catalog search --query "SRM 采购" --json
```
