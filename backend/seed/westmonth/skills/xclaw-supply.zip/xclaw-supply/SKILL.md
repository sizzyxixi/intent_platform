---
name: xclaw-supply
version: 2.2.1
description: "供应链（supply）场景路由：MRP 计划/库存/催货与 SRM 供应商/采购单。用户询问 MRP、SRM、分仓库存或供应商采购时使用。不负责商城采购单展示（xclaw-mall）或 CLI 安装登录（xclaw-cli-assistant）。"
metadata:
  category: solution
  packCode: supply
  requires:
    bins: ["xclaw-cli"]
  cliHelp: "xclaw-cli supply --help"
---

# Xclaw Supply

**开始前 MUST：** 确认 CLI 可用（`doctor` / `auth status`），再读本路由；参数以 live `--help` / `schema` 为准。公共能力见 `xclaw-cli skills read xclaw-cli-assistant`。

登录失败、权限不明、命令树过期 → `xclaw-cli skills read xclaw-cli-assistant references/troubleshooting.md`

## 这条业务线是干什么的

`xclaw-cli supply` 访问 **MRP / SRM** 供应链系统（当前约 15 条顶层子命令，分在 `mrp` 与 `srm` 两组）。

```bash
# BAD — 商城采购订单列表（选品网视图）
xclaw-cli mall sale-order purchase-show-formal-order-list ...

# GOOD — SRM 采购单
xclaw-cli supply srm purchase-order --json ...

# GOOD — MRP 分仓库存
xclaw-cli supply mrp goods-warehouse-inventories --json ...
```

## mrp — 计划、库存、催货

`xclaw-cli supply mrp --help` 当前子命令（说明来自 CLI）：

| 子命令 | 用途 |
|--------|------|
| `goods` | 按 SKU/产品编码查商品，含库存、销量等 |
| `goods-plans` | 计划单基本信息，支持判断是否缺货 |
| `goods-abnormal-plans` | 跟单时效异常的计划单 |
| `goods-order-locks` | 商品被哪些订单占用 |
| `goods-warehouse-inventories` | 各仓库实际/可用/调拨在途库存 |
| `purchase-order-details` | SKU 关联采购单、在途数量、预计到货 |
| `purchase-return-days` | 回货天数分析 |
| `goods-requirement` | **提交催货**（写操作） |
| `goods-requirement-replies` | 按催货单号查回复 |

## srm — 供应商与采购

`xclaw-cli supply srm --help` 当前子命令：

| 子命令 | 用途 |
|--------|------|
| `supplier` | 供应商列表 |
| `purchase-order` | 采购单列表 |
| `processing-order` | 加工单列表 |
| `administrative-order` | 行政采购单列表 |
| `shipment-detail` | 按采购单 ID 查发货明细 |
| `sku-procurement-detail` | 按 SKU 查代采链接、价格、供应商 |

## 典型走法

```bash
xclaw-cli schema supply mrp goods-warehouse-inventories --json
xclaw-cli supply mrp goods-warehouse-inventories --json ...

xclaw-cli schema supply srm purchase-order --json
xclaw-cli supply srm purchase-order --json ...
```

催货（写操作）：

```bash
xclaw-cli schema supply mrp goods-requirement --json
xclaw-cli supply mrp goods-requirement --dry-run --json ...
# 用户确认后再执行
```

## 注意事项

- `goods-requirement` 会写入催货，必须 schema + 用户确认
- 「采购单」一词需分清：**商城** `mall sale-order` vs **SRM** `supply srm purchase-order`
- 不确定时用 `catalog search --query "催货"` / `"采购单"` 并看 `generatedCommandPath`

## 不在本 skill

- 商城订单、发票、1688 → `xclaw-mall`
- 客户/询盘 → `xclaw-operate`
