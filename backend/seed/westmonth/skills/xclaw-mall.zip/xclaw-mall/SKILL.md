---
name: xclaw-mall
version: 2.2.1
description: "选品网/西之月商城（mall）场景路由：销售/采购单、平台订单视图、商品、售后、发票、1688 店铺数据。用户询问商城订单、发票、商品或选品网时使用。不负责 CRM（xclaw-operate）、平台原生 OpenAPI（xclaw-platform）、供应链 MRP/SRM（xclaw-supply）或 CLI 安装登录（xclaw-cli-assistant）。"
metadata:
  category: solution
  packCode: mall
  requires:
    bins: ["xclaw-cli"]
  cliHelp: "xclaw-cli mall --help"
---

# Xclaw Mall

**开始前 MUST：** 确认 CLI 可用（`xclaw-cli doctor --json` / `auth status`），再读本路由；参数以 live `--help` / `schema` 为准。公共能力见 `xclaw-cli skills read xclaw-cli-assistant`。

登录失败、权限不明、命令树过期 → `xclaw-cli skills read xclaw-cli-assistant references/troubleshooting.md`

## 这条业务线是干什么的

`xclaw-cli mall` 访问 **西之月商城/选品网** 聚合后的业务能力（当前 manifest 约 117 条子命令）。用户在聊「商城里的单、货、票、1688 店铺数据」时用这个，不是在聊 CRM，也不是直接调跨境平台 OpenAPI。

```bash
# BAD — 查 CRM 客户地址
xclaw-cli operate customer address list ...

# GOOD — 查商城销售/采购单
xclaw-cli mall sale-order manual-order-search-list --json ...

# BAD — 调 Shopee 卖家 API
xclaw-cli platform shopee ...

# GOOD — 查商城侧平台订单/1688 授权店铺/物流
xclaw-cli mall platform-order logistics-track --json ...
```

## 意图路由

| 用户意图 | 进哪个分组 | 常见子命令（先 `--help` 确认） |
|----------|------------|--------------------------------|
| 销售单、手工单 | `sale-order` | `manual-order-filtering-data` → `manual-order-search-list` |
| 采购订单列表/详情 | `sale-order` | `purchase-show-format-order-search-list` → `purchase-show-formal-order-list` / `purchase-show-formal-order-detail` |
| 物流轨迹、1688 授权店铺 | `platform-order` | `auth-shop-list`、`logistics-track` |
| MCP/TikTok 渠道订单、店铺 | `platform-order` | `mcp-order-list`、`mcp-shop-info` 等 |
| 选品网商品、品牌、分仓库存 | `mall-product` | `brand-list`、`authorize-brands`、`child-warehouses` |
| 三方平台商品 | `platform-product` | `mall platform-product --help` |
| 平台店铺授权 | `platform-store` | `mall platform-store --help` |
| 采购售后 | `after-sale-order` | `purchase-after-sale-list`、`purchase-after-sale-detail` |
| 发票申请 | `ams-invoice` | `invoice-approve`（或 `skills read xclaw-mall` 查路由） |
| PLM 商品 | `plm-product` | `mall plm-product --help` |
| 1688 生意参谋 | `bi-1688-business-advisor` | `mall bi-1688-business-advisor --help` |
| 1688 店铺聊天 | `bi-1688-seller-chat` | 同上 |
| 1688 商家后台 | `bi-1688-seller-console` | 同上 |

完整分组名以 **`xclaw-cli mall --help`** 为准：

`after-sale-order` · `ams-invoice` · `bi-1688-business-advisor` · `bi-1688-seller-chat` · `bi-1688-seller-console` · `mall-product` · `platform-order` · `platform-product` · `platform-store` · `plm-product` · `sale-order`

## 典型走法

### 查销售/手工订单

```bash
xclaw-cli schema mall sale-order manual-order-search-list --json
xclaw-cli mall sale-order manual-order-filtering-data --json   # 先拿筛选项
xclaw-cli mall sale-order manual-order-search-list --json ... # 再查列表
```

### 查物流

```bash
xclaw-cli skills read xclaw-mall references/routing.md
xclaw-cli schema mall platform-order logistics-track --json
xclaw-cli mall platform-order logistics-track --json ...
```

### 开发票 / 查发票

```bash
xclaw-cli mall ams-invoice --help
xclaw-cli schema mall ams-invoice invoice-approve ... --json
```

## 注意事项

- 列表类接口常成对：**筛选项**（`*filtering*` / `*-search-list` 数据）→ **列表/详情**
- 参数名、header（如部分发票接口的 `referer`）以 **schema** 为准
- 写操作前 `--dry-run`，并向用户确认订单号/时间范围

## 不在本 skill

- 客户、询盘、改价、报价 → [`xclaw-operate`](../xclaw-operate/SKILL.md)
- Shopee/Temu 平台原生 API → [`xclaw-platform`](../xclaw-platform/SKILL.md)
- MRP/SRM → [`xclaw-supply`](../xclaw-supply/SKILL.md)

更细的子命令说明：[`references/scenarios.md`](references/scenarios.md)
