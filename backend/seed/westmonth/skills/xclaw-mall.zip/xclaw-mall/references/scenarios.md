# mall 子命令索引

与 `xclaw-cli mall --help` 同步。执行前对目标子命令跑 `schema mall <分组> <子命令> --json`。

## sale-order（销售订单域）

| 子命令 | 说明 |
|--------|------|
| `manual-order-filtering-data` | 手工订单筛选项 |
| `manual-order-search-list` | 手工单列表 |
| `purchase-show-format-order-search-list` | 采购订单筛选项 |
| `purchase-show-formal-order-list` | 采购订单列表 |
| `purchase-show-formal-order-detail` | 采购订单详情 |

## platform-order（三方平台订单域）

| 子命令 | 说明 |
|--------|------|
| `auth-shop-list` / `auth-shop-detail` | 1688 授权店铺 |
| `logistics-track` | 物流轨迹 |
| `mcp-order-list` | MCP 订单列表 |
| `mcp-shop-info` | MCP 店铺详情 |
| `mcp-wholesale-order-detail` | 1688 渠道后台订单详情 |
| `mcp-publish-tiktok-*` | TikTok 类目/资质相关 |

（完整列表：`xclaw-cli mall platform-order --help`）

## mall-product（选品网商品域）

| 子命令 | 说明 |
|--------|------|
| `brand-list` | 品牌列表 |
| `authorize-brands` | 授权品牌 |
| `brand-auth-platform` / `brand-auth-record` | 平台授权、授权记录 |
| `category-tree` | 分类树 |
| `child-warehouses` | 分仓库存 |
| `depots` | 仓库列表 |

## after-sale-order（售后订单域）

| 子命令 | 说明 |
|--------|------|
| `purchase-after-sale-list` | 售后列表 |
| `purchase-after-sale-detail` | 主详情 |
| `purchase-after-sale-other-detail` | 其他信息 |
| `purchase-after-sale-reason-detail` | 售后原因 |

## ams-invoice（财务发票域）

- 分组下含 `invoice-approve`（发票申请相关子命令）

## 1688 BI

- `bi-1688-business-advisor` — 生意参谋
- `bi-1688-seller-chat` — 店铺聊天
- `bi-1688-seller-console` — 商家后台

## platform-product / platform-store / plm-product

各分组子命令以 `--help` 为准。
