# mall：一句话该走哪

| 用户在说 | 命令入口 |
|----------|----------|
| 手工单、销售单 | `mall sale-order manual-order-*` |
| 采购单（商城系统） | `mall sale-order purchase-show-formal-order-*` |
| 物流、到哪了 | `mall platform-order logistics-track` |
| 1688 授权店铺 | `mall platform-order auth-shop-*` |
| 商品、品牌、分仓 | `mall mall-product` |
| 售后 | `mall after-sale-order purchase-after-sale-*` |
| 发票 | `mall ams-invoice` 或 `skills read xclaw-mall` |
| 1688 参谋/聊天 | `mall bi-1688-*` |

和 **operate** 混淆时：用户在问「客户/询盘/改价」→ operate；在问「商城里的单/物流/票」→ mall。

和 **platform** 混淆时：用户在问「选品网/MCP 里看到的单」→ mall `platform-order`；在问「Shopee API 原样接口」→ platform。
