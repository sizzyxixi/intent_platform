---
name: xclaw-operate
version: 2.2.1
description: "运营 CRM（operate）场景路由：客户档案、1688 询盘线索、跟进、改价、定制报价、ITSM 工单。用户询问客户、线索、跟进、改价或工单时使用。不负责商城订单（xclaw-mall）、平台原生 OpenAPI（xclaw-platform）、供应链（xclaw-supply）或 CLI 安装登录（xclaw-cli-assistant）。"
metadata:
  category: solution
  packCode: operate
  requires:
    bins: ["xclaw-cli"]
  cliHelp: "xclaw-cli operate --help"
---

# Xclaw Operate

**开始前 MUST：** 确认 CLI 可用（`doctor` / `auth status`），再读本路由；参数以 live `--help` / `schema` 为准。公共能力见 `xclaw-cli skills read xclaw-cli-assistant`。

登录失败、权限不明、命令树过期 → `xclaw-cli skills read xclaw-cli-assistant references/troubleshooting.md`

## 这条业务线是干什么的

`xclaw-cli operate` 访问 **运营 CRM / 1688 与选品网客户与询盘** 能力（当前约 87 条子命令，分在 6 个顶层分组）。用户在聊「客户是谁、询盘线索、跟进、改价、报价、工单」时用这个，不是在聊商城订单列表或 Shopee API。

```bash
# BAD — 查商城销售/采购单
xclaw-cli mall sale-order manual-order-search-list ...

# GOOD — 查 1688 客户列表
xclaw-cli operate customer customer alibaba search --json ...

# BAD — 调 Temu 卖家 API
xclaw-cli platform temu ...

# GOOD — 订单改价（写操作先 dry-run）
xclaw-cli operate order price-change --dry-run --json ...
```

## 顶层分组（以 `xclaw-cli operate --help` 为准）

| 分组 | 用途 |
|------|------|
| `customer` | 客户档案、地址、联系人、1688/选品网客户、询盘/店铺、跟进任务、报价单、业绩等（命令最多，常需多段路径） |
| `clue` | 1688 询盘线索列表与操作日志 |
| `follow` | 客户跟进记录 |
| `order` | 订单改价及改价审核详情 |
| `pricing` | 定制报价单列表/详情、历史报价 |
| `itsm-ticket` | ITSM 工单查询 |

## 意图路由

| 用户意图 | 进哪个分组 | 常见路径（先 `--help` / `schema` 确认） |
|----------|------------|----------------------------------------|
| 1688 高级客户列表（多条件筛选） | `customer` | `customer customer alibaba search`（`--condition` 必填） |
| 选品网高级客户列表（多条件筛选） | `customer` | `customer customer xuanpin search`（`--condition`） |
| 按旺旺号查 1688 客户简表 | `customer` | `customer customer-mini alibaba search`（`--ww-account`） |
| 搜选品网客户（关键词） | `customer` | `customer global-customer xuanpin search`（`--keyword`） |
| 按名称查选品网客户简表 | `customer` | `customer customer-mini xuanpin search`（`--name`） |
| 选品网客户详情 | `customer` | `customer customer-profile xuanpin get`（`--id` 或 `--xy-customer-mid`） |
| 客户详情、简表 | `customer` | `customer-profile`、`customer-mini`、`customer-column` |
| 收货地址 | `customer` | `customer address alibaba search` |
| 1688 询盘/旺旺询盘 | `customer` / `clue` | `customer inquiry`；`clue inquiry-thread` |
| 跟进记录 | `customer` / `follow` | `customer follow-record`；`follow record` |
| 订单改价 | `order` | `order price-change` |
| 定制报价 | `pricing` | `pricing make`、`pricing make-detail` |
| ITSM 工单 | `itsm-ticket` | `itsm-ticket ticket` |

更细的一句话路由：[`references/routing.md`](references/routing.md)  
子命令索引：[`references/scenarios.md`](references/scenarios.md)

## 典型走法

### 高级客户列表（`customer customer`，1688 / 选品网）

`operate customer customer alibaba search` 与 `operate customer customer xuanpin search` 是 CRM **高级筛选客户列表**，用 `--condition` 传 AND/OR 条件 DSL。单字段快速查优先走下面的「简表 / 全库搜索」。

**先查 schema 与可筛字段：**

```bash
xclaw-cli schema operate customer customer alibaba search --json
xclaw-cli schema operate customer customer xuanpin search --json
xclaw-cli operate customer filter-field alibaba search --model-type alibaba_client --json
xclaw-cli operate customer filter-field xuanpin search --json
```

**`--condition` 建议写进文件，用 `@路径` 传入**（避免 shell 转义 JSON；Windows / PowerShell 尤其需要）：

```bash
# condition.json 示例见下方各场景
xclaw-cli operate customer customer alibaba search \
  --page 1 --size 20 --json \
  --condition @condition.json
```

**1688 — 按旺旺号查高级列表**

场景：查询旺旺号是「我是一块白金」的 1688 客户（已实测 `total: 1`，响应含 `ww_account`、跟进人、关联店铺等完整字段）。

`condition-1688-ww.json`：

```json
{
  "type": "logical",
  "logical": "and",
  "conditions": [
    {
      "type": "condition",
      "field_name": "ww_account",
      "operator": "contains",
      "field_type": "text",
      "value": "我是一块白金"
    }
  ]
}
```

```bash
xclaw-cli operate customer customer alibaba search \
  --page 1 --size 20 --json \
  --condition @condition-1688-ww.json
```

1688 文本字段常用 `contains`；`field_name` 以 `filter-field alibaba search --model-type alibaba_client` 返回的 `field` 为准。

**选品网 — 按关联旺旺号 / 客户名查高级列表**

场景：在选品网 CRM 高级列表里按同一标识检索。字段名与运算符和 1688 **不同**——旺旺号字段是 `ww_accounts`（复数），文本匹配用 `wildcard`（不是 `contains`）；客户名用 `custom_name`。

`condition-xuanpin-ww.json`（按关联旺旺号）：

```json
{
  "type": "logical",
  "logical": "and",
  "conditions": [
    {
      "type": "condition",
      "field_name": "ww_accounts",
      "operator": "wildcard",
      "field_type": "text",
      "value": "我是一块白金"
    }
  ]
}
```

```bash
xclaw-cli operate customer customer xuanpin search \
  --page 1 --size 20 --json \
  --condition @condition-xuanpin-ww.json
```

若 `total: 0`，说明该旺旺号在选品网侧无关联档案（同一买家可能只在 1688 有记录）；可改查 `custom_name` / `company_name`，或改用下方简表 / 全库搜索。

### 按标识快速查客户（简表 / 全库）

同一客户可能在 1688 与选品网各有一条档案；**高级列表**字段最全，**简表**参数更少、适合单字段命中。

**1688 — 按旺旺号（客户简表）**

场景：查询旺旺号是「我是一块白金」的客户信息。

```bash
xclaw-cli schema operate customer customer-mini alibaba search --json
xclaw-cli operate customer customer-mini alibaba search \
  --ww-account "我是一块白金" \
  --page 1 \
  --size 20 \
  --json
```

**选品网 — 按客户名或关键词**

场景：查询名称/关键词为「我是一块白金」的选品网客户。优先用全库搜索；需要简表字段时用 `--name`。

```bash
# 全库关键词搜索（--keyword 必填）
xclaw-cli schema operate customer global-customer xuanpin search --json
xclaw-cli operate customer global-customer xuanpin search \
  --keyword "我是一块白金" \
  --json

# 客户简表按名称
xclaw-cli schema operate customer customer-mini xuanpin search --json
xclaw-cli operate customer customer-mini xuanpin search \
  --name "我是一块白金" \
  --page 1 \
  --size 20 \
  --json
```

命中后查详情：`xclaw-cli operate customer customer-profile xuanpin get --id <客户ID> --json`（或 `--xy-customer-mid`）；1688 详情走 `customer-profile alibaba get`。

### 查客户收货地址

```bash
xclaw-cli schema operate customer address alibaba search --json
xclaw-cli operate customer address alibaba search --json ...
```

### 查 1688 询盘线索

```bash
xclaw-cli operate clue --help
xclaw-cli schema operate clue inquiry-thread --json
xclaw-cli operate clue inquiry-thread --json ...
```

### 订单改价（写操作）

```bash
xclaw-cli schema operate order price-change --json
xclaw-cli operate order price-change --dry-run --json ...
# 用户确认后再去掉 --dry-run
```

### 定制报价单

```bash
xclaw-cli schema operate pricing make --json
xclaw-cli operate pricing make --json ...
```

## 怎么找具体命令

1. `xclaw-cli skills read xclaw-operate references/routing.md`
2. 对目标分组逐层 `--help`（`customer` 下常有 3～4 段路径）
3. `xclaw-cli schema operate <path> --json` 查必填参数
4. 查询加 `--json`；变更先 `--dry-run`

## 注意事项

- `customer customer` 高级列表 **没有** `--keyword`；条件必须走 `--condition` JSON（建议 `@文件`）
- 1688 高级列表 `--page`、`--size`、`--condition` 均必填；选品网 `--condition` 可选但复杂筛选必须传
- 选品网 `condition` 里 `field_name` 写错时可能**静默不过滤**（返回全量 1 万+）；写前查 `filter-field xuanpin search`
- 1688 文本常用 `contains`；选品网文本常用 `wildcard`（见 filter-field 的 `operators.symbol`）
- `customer` 分组命令深、命名重复（如 `customer customer ...`），**禁止凭记忆拼路径**
- 列表命中多条且后续有改价/审批等写操作时，让用户确认目标单号/客户
- 参数名、分页、时间范围以 **schema** 为准

## 不在本 skill

- 商城销售/采购单、发票、物流 → [`xclaw-mall`](../xclaw-mall/SKILL.md)
- Shopee/Temu 等平台卖家 API → [`xclaw-platform`](../xclaw-platform/SKILL.md)
- MRP/SRM、催货、供应商 → [`xclaw-supply`](../xclaw-supply/SKILL.md)
