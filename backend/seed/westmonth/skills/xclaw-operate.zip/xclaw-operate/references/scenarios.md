# operate 子命令索引

与 `xclaw-cli operate --help` 及各分组 `--help` 同步。执行前对目标 leaf 跑 `schema operate <path> --json`。

## customer（客户查询，约 40+ leaf）

常用 leaf（CRM / 1688）：

| 路径片段 | 说明 |
|----------|------|
| `customer customer alibaba search` | 高级筛选 1688 客户列表（`--condition` 必填；旺旺号 `field_name=ww_account`） |
| `customer customer xuanpin search` | 选品网高级客户列表（`--condition`；旺旺号 `field_name=ww_accounts`，文本用 `wildcard`） |
| `customer filter-field alibaba search` | 1688 可筛字段元数据（需 `--model-type alibaba_client`） |
| `customer filter-field xuanpin search` | 选品网可筛字段元数据 |
| `customer customer-mini alibaba search` | 1688 客户简表；按旺旺号用 `--ww-account` |
| `customer global-customer xuanpin search` | 搜索全部选品网客户（`--keyword` 必填） |
| `customer customer-mini xuanpin search` | 选品网客户简表（`--name`、`--xy-customer-id` 等） |
| `customer customer-profile xuanpin get` | 选品网客户详情（`--id` 或 `--xy-customer-mid`） |
| `customer inquiry` | 1688 询盘列表 |
| `customer inquiry-thread` | 1688 询盘线索列表 |
| `customer follow-record` | 跟进记录 |
| `customer follow-task` | 当前跟进任务 |
| `customer pricing` | 报价单列表 |
| `customer shop-chat` | 1688 客户聊天记录 |

完整列表：`xclaw-cli operate customer --help`（含 `bind-audit`、`discount-approval`、`sales-detail` 等）。

## clue（线索查询）

| 子命令 | 说明 |
|--------|------|
| `inquiry-thread` | 1688 询盘线索列表 |
| `inquiry-thread-operate-log` | 询盘线索操作日志 |

## follow（客户跟进）

| 子命令 | 说明 |
|--------|------|
| `record` | 跟进记录列表 |

## order（订单改价）

| 子命令 | 说明 |
|--------|------|
| `price-change` | 提交/查询订单改价（写操作） |
| `price-change-detail` | 改价审核详情 |

## pricing（定制报价）

| 子命令 | 说明 |
|--------|------|
| `make` | 定制报价单列表 |
| `make-detail` | 定制报价单详情 |
| `history-price` | 历史报价信息 |

## itsm-ticket（工单）

| 子命令 | 说明 |
|--------|------|
| `ticket` | 工单列表/查询 |
