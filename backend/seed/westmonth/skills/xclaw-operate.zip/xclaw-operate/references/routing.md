# operate：一句话该走哪

| 用户在说 | 命令入口 |
|----------|----------|
| 1688 高级客户列表 | `operate customer customer alibaba search --condition @<json>` |
| 选品网高级客户列表 | `operate customer customer xuanpin search --condition @<json>` |
| 按旺旺号查 1688 客户（简表） | `operate customer customer-mini alibaba search --ww-account "<旺旺号>"` |
| 搜选品网客户（关键词） | `operate customer global-customer xuanpin search --keyword "<关键词>"` |
| 按名称查选品网客户简表 | `operate customer customer-mini xuanpin search --name "<客户名>"` |
| 客户详情、档案 | `operate customer customer-profile` 或 `--help` 下 profile 类 |
| 收货地址 | `operate customer address alibaba search` |
| 旺旺/1688 询盘 | `operate customer inquiry` 或 `operate clue inquiry-thread` |
| 跟进记录 | `operate follow record` 或 `operate customer follow-record` |
| 改价 | `operate order price-change` |
| 定制报价 | `operate pricing make` |
| ITSM 工单 | `operate itsm-ticket ticket` |

和 **mall** 混淆时：用户在问「商城里的单/物流/发票」→ mall；在问「CRM 客户/询盘/改价」→ operate。

和 **platform** 混淆时：用户在问「店铺卖家 API 原样接口」→ platform；在问「1688 客户/询盘 CRM」→ operate。
